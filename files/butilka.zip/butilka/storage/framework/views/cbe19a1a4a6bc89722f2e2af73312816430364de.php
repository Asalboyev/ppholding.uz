<?php $__env->startSection('content'); ?>

    <main class="location-page">
        <div class="top">
            <div class="container">
                <h1 class="top__title ro-bold"><?php echo e(translation('footer.location')); ?></h1>
                <p class="top__text"><?php echo e(translation('location_desc1')); ?></p>
                <p class="top__text"><?php echo e(translation('location_desc2')); ?></p>
            </div>
        </div>

        <div class="items">
            <div class="container">
                <div class="items__inner">
                    <div class="item">
                        <div class="item__img">
                            <img src="<?php echo e(asset('images/ship.svg')); ?>" alt="">
                        </div>
                        <h5 class="item__title ro-black"><?php echo e(translation('waterway')); ?></h5>
                        <ul class="item__list">
                            <?php echo translation('waterway_sub'); ?>

                        </ul>
                    </div>
                    <div class="item">
                        <div class="item__img">
                            <img src="<?php echo e(asset('images/truck.svg')); ?>" alt="">
                        </div>
                        <h5 class="item__title ro-black"><?php echo e(translation('road_transport')); ?></h5>
                        <ul class="item__list">
                            <?php echo translation('road_transport_sub'); ?>

                        </ul>
                    </div>
                    <div class="item">
                        <div class="item__img">
                            <img src="<?php echo e(asset('images/train.svg')); ?>" alt="">
                        </div>
                        <h5 class="item__title ro-black"><?php echo e(translation('rail_transport')); ?></h5>
                        <ul class="item__list">
                            <?php echo translation('rail_transport_sub'); ?>

                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="bottom">
            <div class="container">
                <p class="bottom__text"><?php echo e(translation('location_desc3')); ?></p>
            </div>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\OSPanel\domains\butilka\resources\views/location.blade.php ENDPATH**/ ?>