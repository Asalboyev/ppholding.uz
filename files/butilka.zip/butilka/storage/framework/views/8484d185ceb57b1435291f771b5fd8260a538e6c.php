<?php $__env->startSection('content'); ?>

    <main class="about-page">
        <div class="top">
            <div class="container">
                <div class="top__inner">
                    <h1 class="top__title ro-bold"><?php echo e(translation('about_company')); ?></h1>
                    <a href="#" class="top__logo">
                        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="">
                    </a>
                </div>
                <p class="text--gray"><?php echo e(translation('about_desc1')); ?></p>
            </div>
        </div>

        <div class="video">
            <div class="container">
                <div class="video__inner">
                    <div class="video-control" id="video-control">
                        <div class="play-btn">
                            <img src="<?php echo e(asset('images/play.svg')); ?>" alt="">
                        </div>
                    </div>
                    <video id="video">
                        <source src="https://denis-creative.com/wp-content/uploads/2018/01/video.mp4" type="video/mp4" />
                        <source src="https://denis-creative.com/wp-content/uploads/2018/01/video.ogv" type="video/ogv" />
                        <source src="https://denis-creative.com/wp-content/uploads/2018/01/video.webm" type="video/webm" />
                    </video>
                </div>
            </div>
        </div>

        <div class="container">
            <p class="text--gray"><?php echo e(translation('about_desc2')); ?></p>
        </div>

        <div class="cards">
            <div class="container">
                <div class="cards__inner">
                    <div class="card">
                        <span class="ir-semibold"><?php echo e(translation('loads_booked_num')); ?></span>
                        <p class="ir-semibold"><?php echo e(translation('loads_booked')); ?></p>
                    </div>
                    <div class="card">
                        <span class="ir-semibold"><?php echo e(translation('average_num')); ?></span>
                        <p class="ir-semibold"><?php echo e(translation('average')); ?></p>
                    </div>
                    <div class="card">
                        <span class="ir-semibold"><?php echo e(translation('lbs_dispatched_num')); ?></span>
                        <p class="ir-semibold"><?php echo e(translation('lbs_dispatched')); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="gallery">
            <div class="gallery__block">
                <div class="gallery__item">
                    <img src="<?php echo e(asset('images/about-gallery-1.jpg')); ?>" alt="">
                </div>
                <div class="gallery__item">
                    <img src="<?php echo e(asset('images/about-gallery-2.jpg')); ?>" alt="">
                </div>
                <div class="gallery__item">
                    <img src="<?php echo e(asset('images/about-gallery-1.jpg')); ?>" alt="">
                </div>
                <div class="gallery__item">
                    <img src="<?php echo e(asset('images/about-gallery-2.jpg')); ?>" alt="">
                </div>
            </div>
            <div class="gallery__block">
                <div class="gallery__item">
                    <img src="<?php echo e(asset('images/about-gallery-3.jpg')); ?>" alt="">
                </div>
                <div class="gallery__item">
                    <img src="<?php echo e(asset('images/about-gallery-4.jpg')); ?>" alt="">
                </div>
                <div class="gallery__item">
                    <img src="<?php echo e(asset('images/about-gallery-3.jpg')); ?>" alt="">
                </div>
                <div class="gallery__item">
                    <img src="<?php echo e(asset('images/about-gallery-4.jpg')); ?>" alt="">
                </div>
            </div>
        </div>

        <div class="container">
            <p class="text--gray"><?php echo e(translation('about_desc3')); ?></p>
        </div>

        <div class="sertificates">
            <div class="container">
                <h3 class="sertificates__title ro-bold"><?php echo e(translation('sertificates')); ?></h3>
                <div class="sertificates__items">
                    <?php $__currentLoopData = $sertificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="sertificates__item">
                        <img src="<?php echo e(asset($item->img)); ?>" alt="">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






                </div>
            </div>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\OSPanel\domains\butilka\resources\views/about.blade.php ENDPATH**/ ?>