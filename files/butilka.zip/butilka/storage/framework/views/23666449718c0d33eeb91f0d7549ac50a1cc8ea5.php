<?php $__env->startSection('content'); ?>

<h1 class="text-uppercase mt-5">languages</h1>

<div class="headcrumbs d-flex mb-3">
  <a href="<?php echo e(route('langs.index')); ?>" class="d-flex text-uppercase me-2" style="opacity:25%">languages</a> >> <a class="d-flex text-uppercase ms-2">create</a>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('langs.store')); ?>" method="post">
  <?php echo csrf_field(); ?>
  <div class="row">
    <div class="col-12 mb-4">
        <div class="card border-0 shadow components-section">
            <div class="card-body">
              <div class="row mb-4">
                  <div class="col-lg-6 col-sm-6">
                      <!-- Form -->
                      <div class="mb-4">
                          <label>Title</label>
                          <input type="text" class="form-control" name="lang" placeholder="lang..." value="<?php echo e(old('lang')); ?>">
                      </div>
                      <div class="my-4">
                        <label>Small text</label>
                        <input type="text" class="form-control" name="small" placeholder="small text..." value="<?php echo e(old('small')); ?>">
                      </div>
                      <!-- End of Form -->
                  </div>
              </div>
              <button class="btn btn-success px-5 text-white" type="submit" style="padding:12px">Save</button>
            </div>
        </div>
    </div>
  </div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\OSPanel\domains\butilka\resources\views/app/langs/create.blade.php ENDPATH**/ ?>