<?php $__env->startSection('content'); ?>

<h1 class="text-uppercase mb-4">languages</h1>

<a href="<?php echo e(route('langs.create')); ?>" class="btn btn-success mb-3 text-white">Add language</a>

<div class="card border-0 shadow mb-4">
  <div class="card-body">
      <div class="table-responsive">
          <table class="table table-centered table-nowrap mb-0 rounded">
              <thead class="thead-light">
                  <tr>
                      <th class="border-0 rounded-start">#</th>
                      <th class="border-0">Title</th>
                      <th class="border-0">Small text</th>
                      <th class="border-0 rounded-end">Actions</th>
                  </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <!-- Item -->
                  <tr>
                      <td><a href="#" class="text-primary fw-bold"><?php echo e($loop->iteration); ?></a></td>
                      <td class="fw-bold"><?php echo e($lang->lang); ?></td>
                      <td><?php echo e($lang->small); ?></td>
                      <td>
                        <div class="actions d-flex flex-column">
                          <?php if($lang->small != 'ru'): ?>
                          <form class="" action="<?php echo e(route('langs.destroy', ['lang' => $lang->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="text-danger bg-transparent border-0 p-0 m-0 mb-3 fw-bolder">delete</button>
                          </form>
                          <?php else: ?>
                          -
                          <?php endif; ?>
                        </div>
                      </td>
                  </tr>
                  <!-- End of Item -->
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
      </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\butilka\resources\views/app/langs/index.blade.php ENDPATH**/ ?>