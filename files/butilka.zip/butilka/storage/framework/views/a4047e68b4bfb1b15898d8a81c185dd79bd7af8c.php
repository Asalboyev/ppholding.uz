<?php $__env->startSection('links'); ?>
    <style>
        @media (min-width: 752px) {
            .gallery__block {
                width: 100%;
                margin: auto!important;
            }
            .gallery__item {
                width: 25%;
                height: 300px;
            }
            .gallery__item img {
                object-fit: cover;
                width: 100%;
                height: 100%;
            }
        }
        .gallery__item img {
            width: 100%;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <main class="about-page">
        <div class="top">
            <div class="container">
                <div class="top__inner">
                    <h1 class="top__title ro-bold"><?php echo e(translation('about_company')); ?></h1>
                    <a href="#" class="top__logo">
                        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="">
                    </a>
                </div>
                <p class="text--gray"><?php echo isset($about->desc1[$lang]) ? $about->desc1[$lang] : $about->desc1['ru']; ?></p>
            </div>
        </div>

        <div class="video">
            <div class="container">
                <div class="video__inner">
                    <div class="video-control" id="video-control">
                        <div class="play-btn">
                            <img src="<?php echo e(asset('images/play.svg')); ?>" alt="">
                        </div>
                    </div>
                    <video id="video">
                        <source src="<?php echo e(asset($about->video)); ?>" type="video/mp4" />
                    </video>
                </div>
            </div>
        </div>

        <div class="container">
            <p class="text--gray"><?php echo isset($about->desc2[$lang]) ? $about->desc2[$lang] : $about->desc2['ru']; ?></p>
        </div>

        <div class="cards">
            <div class="container">
                <div class="cards__inner">
                    <div class="card">
                        <span class="ir-semibold"><?php echo e(isset($about->done1[$lang]) ? $about->done1[$lang] : $about->done1['ru']); ?></span>
                        <p class="ir-semibold"><?php echo e(isset($about->done1_text[$lang]) ? $about->done1_text[$lang] : $about->done1_text['ru']); ?></p>
                    </div>
                    <div class="card">
                        <span class="ir-semibold"><?php echo e(isset($about->done2[$lang]) ? $about->done2[$lang] : $about->done2['ru']); ?></span>
                        <p class="ir-semibold"><?php echo e(isset($about->done2_text[$lang]) ? $about->done2_text[$lang] : $about->done2_text['ru']); ?></p>
                    </div>
                    <div class="card">
                        <span class="ir-semibold"><?php echo e(isset($about->done3[$lang]) ? $about->done3[$lang] : $about->done3['ru']); ?></span>
                        <p class="ir-semibold"><?php echo e(isset($about->done3_text[$lang]) ? $about->done3_text[$lang] : $about->done3_text['ru']); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="gallery">
            <div class="gallery__block">
                <?php $__currentLoopData = $gallery1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="gallery__item">
                    <img src="<?php echo e(asset('images/'.$item->img)); ?>" alt="">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="gallery__block">
                <?php $__currentLoopData = $gallery2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="gallery__item">
                        <img src="<?php echo e(asset('images/'.$item->img)); ?>" alt="">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="container">
            <p class="text--gray"><?php echo isset($about->desc3[$lang]) ? $about->desc3[$lang] : $about->desc3['ru']; ?></p>
        </div>

        <div class="sertificates">
            <div class="container">
                <h3 class="sertificates__title ro-bold"><?php echo e(translation('sertificates')); ?></h3>
                <div class="sertificates__items">
                    <?php $__currentLoopData = $sertificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="sertificates__item">
                        <img src="<?php echo e(asset($item->img)); ?>" alt="">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






                </div>
            </div>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\butilka\resources\views/about.blade.php ENDPATH**/ ?>