<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
        p {
            font-size: 18px;
        }
        ul li {
            font-size: 14px;
        }
        span {
            font-size: 14px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <p>Новый запрос с сайта PPh</p>
    <ul>
        <li>Имя: <span><?php echo e($name); ?></span></li>
        <br>
        <li>Номер телефона: <span><?php echo e($phone_number); ?></span></li>
        <br>
        <?php if(isset($email)): ?>
        <li>Email: <span><?php echo e($email); ?></span></li><br>
        <?php endif; ?>
        <?php if(isset($cv)): ?>
            <li>CV: <span><?php echo e($cv); ?></span></li>
        <?php endif; ?>
    </ul>
</body>
</html>
<?php /**PATH D:\OSPanel\domains\butilka\resources\views/mail.blade.php ENDPATH**/ ?>