<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin=""/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <main class="contacts-page">
        <div class="contacts-top">
            <div class="container">
                <h1 class="title ro-bold"><?php echo e(translation('navbar.contacts')); ?></h1>
                <div class="items">
                    <div class="item">
                        <div class="item__icon">
                            <img src="<?php echo e(asset('images/phone.svg')); ?>" alt="">
                        </div>
                        <div class="item__info">
                            <span class="item__title"><?php echo e(translation('phone_number_txt')); ?></span>
                            <a href="tel:+998889003009" class="item__link ro-medium"><?php echo e(translation('phone_number')); ?>:</a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="item__icon">
                            <img src="<?php echo e(asset('images/email.svg')); ?>" alt="">
                        </div>
                        <div class="item__info">
                            <span class="item__title">E-mail:</span>
                            <a href="mailto:info@ppholding.uz" class="item__link ro-medium"><?php echo e(translation('email')); ?></a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="item__icon">
                            <img src="<?php echo e(asset('images/location.svg')); ?>" alt="">
                        </div>
                        <div class="item__info">
                            <span class="item__title"><?php echo e(translation('address')); ?></span>
                            <p class="item__link ro-medium"><?php echo e(translation('address_sub')); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="contacts-inner">
                <div class="contacts-form">
                    <h4 class="contacts-form__title ro-black"><?php echo e(translation('form_title')); ?></h4>
                    <p class="contacts-form__subtitle"><?php echo e(translation('form_subtitle')); ?></p>
                    <form action="<?php echo e(route('application')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="text" class="contacts-form__input ro-regular" name="name" placeholder="<?php echo e(translation('your_name')); ?>">
                        <input type="text" class="contacts-form__input ro-regular" required name="phone_number" placeholder="<?php echo e(translation('phone_number_txt')); ?>">
                        <input type="text" class="contacts-form__input ro-regular" name="email" placeholder="<?php echo e(translation('your_email')); ?>">
                        <button class="contacts-form__btn ir-semibold"><?php echo e(translation('send')); ?></button>
                    </form>
                </div>
                <div class="contacts-map">
                    <div id="map"></div>
                </div>
            </div>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
    <script src="<?php echo e(asset('js/map.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\butilka\resources\views/contacts.blade.php ENDPATH**/ ?>