<?php $__env->startSection('content'); ?>

    <main class="gallery-page">
        <div class="top">
            <div class="container">
                <div class="top__inner">
                    <h1 class="top__title ro-bold"><?php echo e(translation('navbar.gallery')); ?></h1>
                    <a href="#" class="top__logo">
                        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="">
                    </a>
                </div>
            </div>
        </div>

        <div class="gallery">
            <div class="container">
                <div class="gallery__inner">
                    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="gallery__item">
                        <img src="<?php echo e(asset($photo->img)); ?>" alt="">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





















                </div>
            </div>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\OSPanel\domains\butilka\resources\views/gallery.blade.php ENDPATH**/ ?>