<div class="mb-3 <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fileUploadBlock">
    <p style="font-weight: 600" class="mb-2"><?php echo e($label); ?></p>
    <div class="d-flex flex-wrap previewFiles">
        <?php $__currentLoopData = old($name.'_hidden', $datas); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex align-items-center justify-content-center me-2" style="width: 100px; height: 100px; background-color: #eeeeee82; border-radius: 12px; border: 1px dashed #ccc; cursor: pointer; position: relative">
                <?php if(in_array(pathinfo('/images'.$item)['extension'], ['png', 'jpg', 'jpeg'])): ?>
                    <img src="/images/<?php echo e($item); ?>" alt="" style="height: 100%; width:100%; border-radius: 12px;object-fit: cover;">
                <?php else: ?>
                    <i class="fas fa-file fa-2x" style="color: #29313d;"></i>
                <?php endif; ?>
                <input type="hidden" name="<?php echo e($name); ?>_hidden[]" value="<?php echo e($item); ?>">
                <button class="btn btn-danger rmFile" style="position: absolute;top: -7px;padding: 0.15rem 0.55rem;right: -7px;"><i class="fas fa-times"></i></button>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex align-items-center justify-content-center openFileDialog" style="width: 100px; height: 100px; background-color: #eeeeee82; border-radius: 12px; border: 1px dashed #ccc; cursor: pointer">
            <i class="fas fa-plus fa-2x" style="color: #29313d;"></i>
        </div>
    </div>
    <input class="form-control fileUploadInput" type="file" style="display: none" name="<?php echo e($name); ?>">
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH D:\OSPanel\OSPanel\domains\butilka\resources\views/app/includes/file_upload.blade.php ENDPATH**/ ?>