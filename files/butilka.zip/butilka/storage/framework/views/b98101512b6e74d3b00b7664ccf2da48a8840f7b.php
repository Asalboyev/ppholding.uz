<?php $__env->startSection('content'); ?>

    <main class="product-inner-page">
        <div class="product-inner__slider">
            <div class="product-inner__slider-inner">
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="product-inner__slider-item swiper-slide">
                        <img src="<?php echo e(asset('images/'.$image->img)); ?>" alt="">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






                </div>
                <div class="product-inner__slider-button-next">
                    <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M0.503906 0.569946L6.93391 6.99995L0.503906 13.4299" stroke="#050505" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>
                <div class="product-inner__slider-button-prev">
                    <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7.49597 0.569946L1.06597 6.99995L7.49597 13.4299" stroke="#050505" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>
            </div>
        </div>

        <div class="info">
            <div class="container">
                <h2 class="info__title ro-bold"><?php echo e(isset($product->title[$lang]) ? $product->title[$lang] : $product->title['ru']); ?></h2>
                <p class="info__subtitle">Артикул: <?php echo e($product->vendor_code); ?></p>
                <p class="info__text"><?php echo isset($product->desc[$lang]) ? $product->desc[$lang] : $product->desc['ru']; ?></p>
            </div>
        </div>

        <div class="slider">
            <div class="container">
                <div class="slider__inner">
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $other; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product-card swiper-slide">
                            <a href="<?php echo e(route('product', ['id' => $product->id])); ?>">
                                <div class="product-card__img">
                                    <img src="<?php echo e(asset($product->main_img)); ?>" alt="">
                                </div>
                                <p class="product-card__title ro-bold"><?php echo e(isset($product->title[$lang]) ? $product->title[$lang] : $product->title['ru']); ?></p>
                                <p class="product-card__subtitle">Артикул: <?php echo e($product->vendor_code); ?></p>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

















































                    </div>
                    <div class="slider-button-next">
                        <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M0.503906 0.569946L6.93391 6.99995L0.503906 13.4299" stroke="#050505" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <div class="slider-button-prev">
                        <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M7.49597 0.569946L1.06597 6.99995L7.49597 13.4299" stroke="#050505" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/libs.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/slider.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\OSPanel\domains\butilka\resources\views/product.blade.php ENDPATH**/ ?>