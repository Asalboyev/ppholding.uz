<?php $__env->startSection('content'); ?>

    <main class="news-page">
        <div class="top">
            <div class="container">
                <div class="top__inner">
                    <h1 class="top__title ro-bold"><?php echo e(translation('navbar.news')); ?></h1>
                    <a href="#" class="top__logo">
                        <img src="images/logo.png" alt="">
                    </a>
                </div>
            </div>
        </div>

        <div class="news__cards">
            <div class="container">
                <div class="news__cards-inner">
                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="news__card">
                        <p class="news__card-date"><?php echo e(date('j.n.Y', strtotime($post->created_at))); ?></p>
                        <div class="news__card-img">
                            <img src="<?php echo e(asset($post->img)); ?>" alt="">
                        </div>
                        <p class="news__card-title"><?php echo e(isset($post->title[$lang]) ? $post->title[$lang] : $post->title['ru']); ?></p>
                        <a href="<?php echo e(route('post', ['id' => $post->id])); ?>" class="link link--blue news__card-link">
                            <span><?php echo e(translation('more_details')); ?></span>
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10.664 6.05301L14.611 10L10.664 13.947M5.413 10H14.599M19.334 10C19.334 15.1556 15.1546 19.335 9.999 19.335C4.84342 19.335 0.664001 15.1556 0.664001 10C0.664001 4.84443 4.84342 0.665009 9.999 0.665009C15.1546 0.665009 19.334 4.84443 19.334 10Z" stroke="#2E57EA" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>








































































































                </div>
                <?php echo e($news->links()); ?>


















            </div>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\OSPanel\domains\butilka\resources\views/news.blade.php ENDPATH**/ ?>