<?php $__env->startSection('content'); ?>

<h1 class="text-uppercase mb-4">applications</h1>

<div class="card border-0 shadow mb-4">
  <div class="card-body">
      <div class="table-responsive">
          <table class="table table-centered table-nowrap mb-0 rounded">
              <thead class="thead-light">
                  <tr>
                      <th class="border-0 rounded-start">#</th>
                      <th class="border-0">Name</th>
                      <th class="border-0">Phone number</th>
                      <th class="border-0">Email</th>
                      <th class="border-0 rounded-end">Actions</th>
                  </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <!-- Item -->
                  <tr>
                      <td><a href="#" class="text-primary fw-bold"><?php echo e(($applications ->currentpage()-1) * $applications ->perpage() + $loop->index + 1); ?></a></td>
                      <td class="fw-bold"><?php echo e($application->name); ?></td>
                      <td><?php echo e($application->phone_number); ?></td>
                      <td><?php echo e($application->email); ?></td>
                      <td>
                        <div class="actions d-flex flex-column">
                          <form class="" action="<?php echo e(route('applications.destroy', ['application' => $application->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                              <?php echo method_field('delete'); ?>
                            <button type="submit" class="text-danger bg-transparent border-0 p-0 m-0 mb-3 fw-bolder">delete</button>
                          </form>
                        </div>
                      </td>
                  </tr>
                  <!-- End of Item -->
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
          <div class="mt-4">
            <?php echo $applications->links(); ?>

          </div>
      </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\butilka\resources\views/app/applications/index.blade.php ENDPATH**/ ?>