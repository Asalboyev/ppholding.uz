<?php $__env->startSection('content'); ?>

    <main class="catalog-page">
        <div class="main-section">
            <div class="container">
                <h1 class="main-section__title ro-bold"><?php echo e(translation('catalog.product_catalog')); ?></h1>
                <div class="main-section__img">
                    <img src="<?php echo e(asset('images/catalog.png')); ?>" alt="">
                </div>
            </div>
        </div>
        <?php $__currentLoopData = $catalog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product-banner">
            <div class="container">
                <div class="product-banner__inner">
                    <div class="product-banner__info">
                        <p class="product-banner__subtitle"><?php echo e(translation('products')); ?></p>
                        <h5 class="product-banner__title ro-bold"><?php echo e(isset($item->title[$lang]) ? $item->title[$lang] : $item->title['ru']); ?></h5>
                        <a href="<?php echo e(route('catalog-inner', ['id' => $item->id])); ?>" class="button button--white product-banner__btn ro-bold"><?php echo e(translation('catalog.show_all_products')); ?></a>
                    </div>
                    <div class="product-banner__img">
                        <img src="<?php echo e(asset('images/product-banner.png')); ?>" alt="">
                    </div>
                </div>
            </div>
        </div>

        <div class="slider">
            <div class="container">
                <div class="slider__inner">
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $item->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product-card swiper-slide">
                            <a href="<?php echo e(route('product', ['id' => $product->id])); ?>">
                                <div class="product-card__img">
                                    <img src="<?php echo e(asset($product->main_img)); ?>" alt="">
                                </div>
                                <p class="product-card__title ro-bold"><?php echo e(isset($product->title[$lang]) ? $product->title[$lang] : $product->title['ru']); ?></p>
                                <p class="product-card__subtitle"><?php echo e(translation('vendor_code')); ?> <?php echo e($product->vendor_code); ?></p>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

















































                    </div>
                    <div class="slider-button-next">
                        <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M0.503906 0.569946L6.93391 6.99995L0.503906 13.4299" stroke="#050505" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <div class="slider-button-prev">
                        <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M7.49597 0.569946L1.06597 6.99995L7.49597 13.4299" stroke="#050505" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>









































































































































    </main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/libs.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/slider.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\butilka\resources\views/catalog.blade.php ENDPATH**/ ?>