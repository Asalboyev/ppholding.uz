<?php $__env->startSection('content'); ?>

    <h1 class="text-uppercase mt-5">news</h1>

    <div class="headcrumbs d-flex mb-3">
        <a href="<?php echo e(route('news.index')); ?>" class="d-flex text-uppercase me-2" style="opacity:25%">news</a> >> <a class="d-flex text-uppercase ms-2">create</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('news.store')); ?>" method="post" enctype='multipart/form-data'>
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-12 mb-4">
                <div class="card border-0 shadow components-section">
                    <div class="card-body">
                        <nav>
                            <div class="nav nav-tabs border-bottom mb-4" id="nav-tab" role="tablist">
                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button class="nav-link border-bottom" id="<?php echo e($language->lang); ?>-tab" data-bs-toggle="tab" data-bs-target="#<?php echo e($language->lang); ?>" type="button" role="tab" aria-controls="<?php echo e($language->lang); ?>" aria-selected="true"><?php echo e($language->lang); ?></button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane fade" id="<?php echo e($language->lang); ?>" role="tabpanel" aria-labelledby="<?php echo e($language->lang); ?>-tab">
                                    <div class="row mb-4">
                                        <div class="col-lg-6 col-sm-6">
                                            <!-- Form -->
                                            <div class="mb-4">
                                                <label for="email">Title</label>
                                                <input type="text" class="form-control" name="title[<?php echo e($language->small); ?>]" placeholder="title" value="<?php echo e(old('title.'.$language->small)); ?>">
                                            </div>
                                            <div class="my-4">
                                                <label for="textarea">Description</label>
                                                <textarea class="form-control ckeditor" placeholder="Enter your description..." id="textarea" rows="4" name="desc[<?php echo e($language->small); ?>]"><?php echo e(old('desc.'.$language->small)); ?></textarea>
                                            </div>
                                            <!-- End of Form -->
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="row mb-4">
                            <div class="col-lg-6 col-sm-6">
                                <div class="mb-3">
                                    <label for="formFile" class="form-label">Image</label>
                                    <input class="form-control" type="file" name="img">
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-success px-5 text-white" type="submit" style="padding:12px">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\OSPanel\domains\butilka\resources\views/app/news/create.blade.php ENDPATH**/ ?>